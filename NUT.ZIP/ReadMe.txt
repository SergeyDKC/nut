解压zip后打开文件夹，sudo运行install.sh脚本以执行安装
安装后配置文件在 /usr/local/ups/etc 目录中,根据NUT要求配置即可
runCmd.sh脚本包含一些基本的服务启动命令,不需要可以无视

upsdrvctl等命令程序在 /usr/local/ups/sbin 目录中 (e.g. sudo /usr/local/ups/sbin/upsdrvctl start  启动ups驱动)
upsc等命令在 /usr/loacl/ups/bin 目录中 (e.g. sudo /usr/local/ups/bin/upsc MyUpsName  查看指定ups状态)
