
sudo systemctl enable nut-server.service
sudo systemctl start nut-server.service
sudo systemctl start nut-client.service
sudo /usr/local/ups/sbin/upsdrvctl start
