#!/bin/sh 
sudo cp -rf ./lib/systemd/system/* /usr/lib/systemd/system
sudo cp -rf ./lib/systemd/system-shutdown/* /usr/lib/systemd/system-shutdown
sudo cp -rf ./lib/udev/rules.d/* /usr/lib/udev/rules.d

sudo cp -rf ./usr/lib/tmpfiles.d/* /usr/lib/tmpfiles.d
sudo cp -rf ./usr/local/lib/python3.10/  /usr/local/lib

sudo cp -rf ./usr/local/ups  /usr/local

mkdir -p /var/state/ups
chmod 777 /var/state/ups

apt-get install libusb-dev


